//当网页加载完成自动发送请求
//data/header.php  <div id="header"></div>
//data/footer.php  <div id="footer"></div>
$(function(){
  $("#header").load("data/header.php");
	$("#footer").load("data/footer.php");
});

var loginUid = 0;
var loginUname = "";
//1:用户登录
//1.1 为提交按钮添加点击事件
$("#bt-login").click(function(){
//1.2 获取用户名密码
var n = $("#uname");
var p  = $("#upwd");
//1.3 发送ajax
$.ajax({
   type:"POST",
	 url:"data/user_login.php",
	 data:{uname:n.val(),upwd:p.val()},
   success:function(data){
		if(data.code<0){
		  $("p.alert").html(data.msg);
		}else{
		  $(".modal").hide();
			$("#welcome>span").html("欢迎回来:"+data.uname)
      loginUid = data.uname;
			loginUname = data.uid;
		}
	 },
	 error:function(data){
	  //console.log("响应消息失败!");
		//$(".modal").hide();
	 },
});
//1.4 返回错误: 在错误提示框 
//    用户名或密码不正确
//1.5 返回正确: 将当前登录框隐藏
//1.6 欢迎回来: xxx
});
//2:浏览商品
//3:浏览商品(分页)
//4:添加购物车
//5:查看购物车